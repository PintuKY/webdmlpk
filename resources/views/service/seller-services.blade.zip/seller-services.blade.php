@extends('layouts.app')

@section('content')

    <section class="dir-alp dir-pa-sp-top">
        <div class="container">
            <div class="row">
                <div class="dir-alp-tit">
                    <h1>Shop now in {{$shop->shop_name}}</h1>
                    <ol class="breadcrumb">
                        <li><a href="#">Home</a> </li>
                        <li><a href="#">Listing</a> </li>
                        <li class="active">Shop List</li>
                    </ol>
                </div>
            </div>
            <div class="row">
                <div class="dir-alp-con">
                    <div class="col-md-3 dir-alp-con-left">
                        <div class="dir-alp-con-left-1">
                            <h3>Categories </h3>
                        </div>
                        <div class="dir-hom-pre dir-alp-left-ner-notb">


                        </div>
                    </div>
                    <div class="col-md-9 dir-alp-con-right">
                        <div class="dir-alp-con-right-1">
                            <div class="row">
                                @foreach($services as $product)
                                    <div class="col-md-4">
                                        <div class="home-list-pop">
                                            <!--POPULAR LISTINGS IMAGE-->
                                            <div class="col-lg-12 col-md-6 col-sm-6 col-xs-6">
                                                <img src="{{asset('public/uploads/images')}}/{{$product->image}}" alt="{{$product->name}}" /> </div>
                                            <!--POPULAR LISTINGS: CONTENT-->
                                            <div class="col-md-12">
                                                <a href="{{url('sellerServices',$shop->id)}}}}"><h3>{{$product->name}}</h3></a>

                                                <div class="row">
                                                    <div class="col-sm-6">
                                                        <h4>Rs {{$product->price}}</h4>
                                                    </div>


                                                </div>

                                                <!--	<span class="home-list-pop-rat">4.2</span> -->

                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                            <div class="row">
                                <ul class="pagination list-pagenat">
                                    <li class="disabled"><a href="#!!"><i class="material-icons">chevron_left</i></a> </li>
                                    <li class="active"><a href="#!">1</a> </li>
                                    <li class="waves-effect"><a href="#!">2</a> </li>
                                    <li class="waves-effect"><a href="#!">3</a> </li>
                                    <li class="waves-effect"><a href="#!">4</a> </li>
                                    <li class="waves-effect"><a href="#!">5</a> </li>
                                    <li class="waves-effect"><a href="#!">6</a> </li>
                                    <li class="waves-effect"><a href="#!">7</a> </li>
                                    <li class="waves-effect"><a href="#!">8</a> </li>
                                    <li class="waves-effect"><a href="#!"><i class="material-icons">chevron_right</i></a> </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

@endsection
