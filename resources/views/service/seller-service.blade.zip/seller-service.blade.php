@extends('layouts.app')
@section('content')
    <section class="p-about com-padd">
        <div class="container">
            <div class="row blog-single con-com-mar-bot-o">
                <div class="col-md-4">
                    <div class="blog-img">
                        <img src="{{asset('public/uploads/images')}}/{{$sellerServices->image}}" alt="{{$sellerServices->name}}" />
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="page-blog">
                        <h3>{{$sellerServices->name}}</h3>

                        <div class="row">
                            <div class="col-sm-2">
                                <h4>Rs {{$sellerServices->price}}</h4>
                            </div>
                            <div class="col-sm-2">
                                <p>Rs <del> {{$sellerServices->price}} </del>
                                </p>
                            </div>
                        </div>
                        <div class="">
                            <div class="quantity buttons_added">
                                <input type="button" value="-" class="minus">
                                <input type="number" step="1" min="1" max="" name="quantity" value="1" title="Qty" class="input-text qty text" size="4" pattern="" inputmode="">
                                <input type="button" value="+" class="plus">
                            </div>
                            <br>
                            <br>
                        </div>
                        <div class="col-md-12" style="padding-top:15px;">
                            <h4>Seller </h4>
                            <p>{{$sellerServices->seller->shop_name}}</p>

                            <h4> Description </h4>
                            <p>{{$sellerServices->description}}</p>
                        </div>

                        <div class="share-btn share-pad-bot" style="padding-top:40%;">
                            <ul>
                                <li><a href="#"><i class="fa fa-facebook fb1"></i> Share On Facebook</a>
                                </li>
                                <li><a href="#"><i class="fa fa-twitter tw1"></i> Share On Twitter</a>
                                </li>
                                <li><a href="#"><i class="fa fa-google-plus gp1"></i> Share On Google Plus</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

@endsection
